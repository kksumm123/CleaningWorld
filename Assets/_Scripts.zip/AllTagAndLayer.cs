﻿public static class AllTagAndLayer
{
    public static readonly string Player = "Player";
}
