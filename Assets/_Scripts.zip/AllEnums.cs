﻿public enum GarbageType
{
    None,

    Can,
    Food,
    Glass,
    Paper,
    Plastic,
}

public enum GarbageDetailType
{
    None,

    Can1,
    Can2,
    Can3,

    Food1,
    Food2,
    Food3,

    Glass1,
    Glass2,
    Glass3,

    Paper1,
    Paper2,
    Paper3,

    Plastic1,
    Plastic2,
    Plastic3,
}

public enum IconType
{
    None,

    Can,
    Food,
    Glass,
    Paper,
    Plastic,
}